var a=50;
var b=100;
var c=a+b;
console.log(c);

